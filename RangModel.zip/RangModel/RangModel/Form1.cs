﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RangModel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        RangModel model;
        Random rnd = new Random();
        string title = "Задача ";
        int counter = 1;

        private void Button1_Click(object sender, EventArgs e)
        {
            calc();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            addtask();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            sort();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            calc();
            sort();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            counter = 1;
        }
       
        /// <summary>
        /// Добавляем случайную задачу в таблицу
        /// </summary>
        private void addtask()
        {
            dataGridView1.Rows.Add(new object[] {
                title + counter++,
                rnd.Next(10, 99) * 0.01,
                rnd.Next(10, 99) * 0.01,
                rnd.Next(10, 99) * 0.01,
                rnd.Next(2)
                });
        }
        
        /// <summary>
        /// Расчитаем приоритеты
        /// </summary>
        private void calc()
        {
            model = new RangModel();
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                model.AddTask(
                    dataGridView1[0, i].Value.ToString(),
                    Convert.ToSingle(dataGridView1[1, i].Value.ToString().Replace('.', ',')),
                    Convert.ToSingle(dataGridView1[2, i].Value.ToString().Replace('.', ',')),
                    Convert.ToSingle(dataGridView1[3, i].Value.ToString().Replace('.', ',')),
                    Convert.ToBoolean(dataGridView1[4, i].Value));
            }

            model.CalcPriory();

            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1[5, i].Value = model.listTasks[i].v.ToString();
            }
        }
        
        /// <summary>
        /// Проранжируем в порядке убывания
        /// </summary>
        private void sort()
        {
            model.SortMyTasks();
            dataGridView1.Rows.Clear();
            foreach (var item in model.listTasks)
            {
                dataGridView1.Rows.Add(
                item.name,
                item.p,
                item.u,
                item.k,
                item.a,
                item.v);
            }
        }
    }
}
