﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RangModel
{
    class RangModel
    {
        public List<MyTask> listTasks { get; set; }

        public RangModel()
        {
            listTasks = new List<MyTask>();
        }

        public RangModel(List<MyTask> MyTasks)
        {
            listTasks = MyTasks;
        }
        
        /// <summary>
        /// Добавляем задачу в лист
        /// </summary>
        /// <param name="name">Название задачи</param>
        /// <param name="p">Вероятность</param>
        /// <param name="u">Ущерб</param>
        /// <param name="k">Функция качества</param>
        /// <param name="a">Функция принадлежности</param>
        public void AddTask(string name, float p, float u, float k, bool a)
        {
            listTasks.Add(new MyTask
            {
                name = name,
                p = p,
                u = u,
                k = k,
                a = a
            });
        }
       
        /// <summary>
        /// Добавляем задачу в лист
        /// </summary>
        /// <param name="task">Задача</param>
        public void AddTask(MyTask task)
        {
            listTasks.Add(task);
        }
        
        /// <summary>
        /// Расчет приоритетов
        /// </summary>
        public void CalcPriory()
        {
            foreach (var item in listTasks)
            {
                item.v = item.p * item.u * item.k * Convert.ToInt32(item.a);
            }
        }
       
        /// <summary>
        /// Сортировка листа задач по убыванию значения приоритета
        /// </summary>
        public void SortMyTasks()
        {
            var SortTasks = (from result in listTasks
                            orderby result.v descending
                            select result);
            listTasks = SortTasks.ToList();
        }
    }
}
