﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RangModel
{
    /// <summary>
    /// Обьект задачи
    /// </summary>
    class MyTask
    {
        public string name { get; set; } // Название
        public float p { get; set; }     // Вероятность
        public float u { get; set; }     // Ущерб
        public float k { get; set; }     // Функция качества
        public bool a { get; set; }      // Функция принадлежности
        public float v { get; set; }     // Расчетный приоритет задачи
    }
}
